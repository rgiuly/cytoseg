function scoreImg = biopsyTopClassify(imgName,tempNo)
% function scoreImg = biopsyTopClassify(imgName)
% Also updates the annotation file
% imgName.jpg.ann is copied to oldAnnotations/imgName.iterNo.jpg.ann
% imgName.jpg.ann afterwards has all the earlier negatives and positives
% along with positives from classification. 


if(nargin<2);
  tempNo = randint(1,1,100);
end

iter = findIteration('top');
curIters.('cancer') = findIteration('cancer');
curIters.('gland') = findIteration('gland');
curIters.('grade5') = findIteration('grade5');
curIters.('top') = findIteration('top');

scoreFileName = sprintf('../images/biopsies/whole/top_scores/score_%s.mat',imgName);
if (exist(scoreFileName,'file'))
  eval(['load ' scoreImgFile]);
  if (prevIters.('cancer') ~= curIters.('cancer') || ...
    prevIters.('gland') ~= curIters.('gland') || ...
    prevIters.('grade5') ~= curIters.('grade5') || ...
    prevIters.('top') ~= curIters.('top'))
  else
    return;
  end
end


boxSize = 60;
propsBins{1} = [-inf -10 -5 -1 0 1 5 10 inf];
propsBins{2} = [-inf -10 -5 -1 0 1 5 10 inf];
propsBins{3} = [-inf -10 -5 -1 0 1 5 10 inf];


fprintf('    Classifying %s for Top Level.. \n',imgName);
imgFileName = sprintf('../images/biopsies/whole/%s.jpg', imgName);
img = imread(imgFileName);
[h w d] = size(img);

scoreImg = -inf*ones(h,w);
t1 = clock;

% Find the low level structures.
maxPad = boxSize;
blockStep = 4*boxSize;
blockSize = 4*boxSize;
padH = ceil(h/blockStep)*blockStep;
padW = ceil(w/blockStep)*blockStep;
img(h:padH,w:padW,:)=250;
allPropsImg = -inf*ones(padH,padW,3);

if(exist(scoreFileName,'file'))
  evalStr = sprintf('load ../images/biopsies/top_scores/score_%s.mat',iter,imgName);
  eval(evalStr);
  if (prevIters.('cancer') ~= curIters.('cancer') || ...
     prevIters.('gland') ~= curIters.('gland')   || ...
     prevIters.('grade5') ~= curIters.('grade5'))
    findLowLevelStructs = 1;
    prevIters = curIters;
  else
    findLowLevelStructs = 0;
    scoreImg = -inf*ones(h,w);
  end
else
  findLowLevelStructs = 1;
  prevIters = curIters;
end

if(findLowLevelStructs)
for blockX = 1:blockStep:padW
  for blockY = 1:blockStep:padH

    fprintf('Block:X=%d to %d, Y = %d to %d\n',blockX,blockX+blockSize-1,...
      blockY,blockY+blockSize-1);

    padding = findPadding(blockX,blockY,padW,padH,maxPad,blockSize);

    % Ignore patches that have low saturation
    tempImg = img(blockY:blockY+blockSize-1,blockX:blockX+blockSize-1,:);
    tempHsv = rgb2hsv(tempImg);
    tempSat = tempHsv(:,:,2);
    if(prctile(tempSat,80)<0.3); continue; end
    
    tempImg = img(blockY-padding(1):blockY+blockSize-1+padding(3),...
      blockX-padding(2):blockX+blockSize-1+padding(4),:);
    
    % Find the low level structures.
    propsImg= blockProps(tempImg,padding,tempNo);
    
    allPropsImg(blockY:blockY+blockSize-1,blockX:blockX+blockSize-1,:) = propsImg;

  end
  evalStr = sprintf('save ../images/biopsies/top_scores/score_%s prevIters scoreImg allPropsImg',imgName);
  eval(evalStr);
end

allPropsImg(h+1:padH,:,:)=[];
allPropsImg(:,w+1:padW,:)=[];

img(h+1:padH,:,:)=[];
img(:,w+1:padW,:)=[];

t2 = clock;
fprintf('    Time to classify low level structures %s: %.1f secs\n',imgName,etime(t2,t1))
end
% Done with low level structures.


% Classify higher level patches.

numBlocks = 0;
t1 = clock;
pixPatch=-ones(ceil(h/boxSize*2),ceil(w/boxSize*2));
strLen = 0;
for blockX = 1:boxSize/2:w-2*boxSize
  for blockY = 1:boxSize/2:h-2*boxSize

    curPatch = img(blockY:blockY+2*boxSize-1,blockX:blockX+2*boxSize-1,:);
    hsvPatch = rgb2hsv(curPatch);
    satPatch = hsvPatch(:,:,2);
    if(prctile(satPatch(:),80)<0.3);continue;end % Ignore less saturated patches
    numBlocks = numBlocks+1;

    clearStr = repmat('\b',[1 strLen]);
    fprintf(clearStr);
    curStr = sprintf('--Patch:X=%d to %d, Y = %d to %d',blockX,blockX+2*boxSize-1,...
      blockY,blockY+2*boxSize-1);
    strLen = length(curStr);
    fprintf(curStr);

    tempImg = img(blockY:blockY+2*boxSize-1,blockX:blockX+2*boxSize-1,:);
    tempPropsImg = allPropsImg(blockY:blockY+2*boxSize-1,blockX:blockX+2*boxSize-1,:);

    imgPosProps = topGetProps(tempImg,1,tempPropsImg,propsBins);
    tscores = boostClassify(['top_predict_iter' num2str(iter) 'Vect'],imgPosProps);
    
    scoreImg(blockY+1:blockY+2*boxSize,blockX+1:blockX+2*boxSize) = tscores;
    
    if(tscores>0);
      pixPatch((blockY-1)*2/boxSize+1,(blockX-1)*2/boxSize+1)=tscores;
    end

    if(mod(numBlocks,10)==9)
      evalStr = sprintf('save ../images/biopsies/top_scores/score_%s prevIters scoreImg allPropsImg pixPatch',imgName);
      eval(evalStr);
    end

  end
end

% Done with higher level patches
t2 = clock;
fprintf('\n    Time to classify %s: %.1f secs\n',imgName,etime(t2,t1))
fprintf('    Number of patches %d\n',numBlocks)

%createSmallPatches(imgName);
patchList = findUniquePatches(pixPatch,boxSize/2);

% Update annotation file
fprintf('Updating annotation file..\n');

annFileName = [imgFileName '.ann'];
cleanAnnFileName = sprintf('../images/biopsies/whole/oldAnnotations/%s.clean.%d.jpg.ann',imgName,iter);

if(exist(cleanAnnFileName,'file'))
  copyfile(cleanAnnFileName,annFileName);
end

annFile = fopen(annFileName,'a');
for i=1:size(patchList,1)
  fprintf(annFile,'Box: %d %d Predicted\n',patchList(i,1),patchList(i,2));
end
fprintf(annFile,'Suspicious:');
for x = 1:size(pixPatch,2)
  for y=1:size(pixPatch,1)
    if pixPatch(y,x)>0
      fprintf(annFile,' (%d,%d)',x*boxSize/2,y*boxSize/2);
    end
  end
end
fprintf(annFile,'\n');
fclose(annFile);
%%% Done..



function propsImg = blockProps(blockImg,padding,tempNo)
%%% Classifies a block of image
%%% Padding is the padding added to image. 

imwrite(blockImg,sprintf('../images/biopsies/temp%d.jpg',tempNo),'jpg');
tempImgName = sprintf('temp%d',tempNo);

propsImg(:,:,1) = biopsyClassify('gland',tempImgName,1);
propsImg(:,:,2) = biopsyClassify('cancer',tempImgName,1);
propsImg(:,:,3) = biopsyClassify('grade5',tempImgName,1);
propsImg = propsImg(padding(1)+1:end-padding(3),padding(2)+1:end-padding(4),:);
