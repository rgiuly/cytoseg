function props = findExternalEdgeProps(img,regions,dFactors,bins,selRegions,extraStr)
% function props = findExternalEdgeProps(img,regions,dFactors,extraStr,selRegions)

[lab ncomp] = bwlabel(regions,4);
[h w d] =size(img);

if(nargin<6)
  extraStr = '';
end

if(nargin<5)
  selRegions = true(h,w);
end


for df = dFactors

  extRatioFeatureName{df}=['ext_ratio_' num2str(df) extraStr];
  dummyStruct.(extRatioFeatureName{df}) = 1;
  
  for i=1:size(img,3)

    extMeanFeatureName{df}{i}=['ext_mean_' num2str(i) '_' num2str(df) extraStr];
    dummyStruct.(extMeanFeatureName{df}{i}) = 0;
    extVarFeatureName{df}{i}=['ext_var_' num2str(i) '_' num2str(df) extraStr];
    dummyStruct.(extVarFeatureName{df}{i}) = 0;
    
   for binNo = 1:length(bins{i})-1
     extHistFeatureName{df}{i}{binNo}=['ext_hist_' num2str(i) '_' num2str(df) extraStr '_bin_' num2str(binNo) ];
     dummyStruct.(extHistFeatureName{df}{i}{binNo}) = 0;
    end

  end
end
  
props = repmat(dummyStruct,[ncomp 1]);

if(ncomp==0); return; end;

bbprop = regionprops(lab,'BoundingBox');

for df = dFactors
  dd{df} = strel('disk',df);
end

maxD = max(dFactors(:));

for ndx=1:ncomp
  ll = max(floor(bbprop(ndx).BoundingBox(1))-maxD,1);
  uu = max(floor(bbprop(ndx).BoundingBox(2))-maxD,1);
  rr = min(floor(bbprop(ndx).BoundingBox(1)+bbprop(ndx).BoundingBox(3))+maxD,w);
  bb = min(floor(bbprop(ndx).BoundingBox(2)+bbprop(ndx).BoundingBox(4))+maxD,h);
  ss = imfill(lab(uu:bb,ll:rr)==ndx,'holes');
  ssPack = bwpack(ss);
  ssRows = size(ss,1);
  
  for df = dFactors
    dilatedss = bwunpack(imdilate(ssPack,dd{df},'ispacked'),ssRows);
    allOutside = dilatedss&(~ss);
    outside = allOutside & selRegions(uu:bb,ll:rr);
    if (sum(allOutside(:))>0)
      props(ndx).(extRatioFeatureName{df})= sum(outside(:))/sum(allOutside(:));
    end

    if(sum(outside(:))); 
      for i=1:d
        pp = img(uu:bb,ll:rr,i);
        curVals = pp(outside);
        props(ndx).(extMeanFeatureName{df}{i}) = mean(curVals);
        props(ndx).(extVarFeatureName{df}{i})= std(curVals);

        
        histVals = histc(curVals,bins{i});
        histVals = histVals./sum(histVals);
        for binNo = 1:length(bins{i})-1
          props(ndx).(extHistFeatureName{df}{i}{binNo}) = histVals(binNo);
        end
        
      end
    end
  end
end
