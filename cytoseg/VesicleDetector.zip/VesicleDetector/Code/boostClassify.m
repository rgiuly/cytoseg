function scores = boostClassify(predName,data)

tfields = fieldnames(data);
nfields = length(tfields);
modData = zeros(length(data),nfields);
for ndx=1:length(data)
  for fld=1:nfields
    modData(ndx,fld)=data(ndx).(tfields{fld});
  end
end
eval(sprintf('scores = %s(modData);',predName));
