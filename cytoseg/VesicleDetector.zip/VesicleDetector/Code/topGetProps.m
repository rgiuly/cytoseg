function trainProps = topGetProps(img,curLabel,extraImg,extraImgBins)
% finds top level features for biopsy images 

biopsyTopFunctions = {sprintf('findLogProps(hsvimg,imgRegions,\''hist\'',bins)'),...
         'labelProps(numRegions,curLabel)',...
         sprintf('findStructureProps(extraImg,\''\'',extraImgBins)'),...
       };


imgRegions = ones(size(img,1),size(img,2));
hsvimg = rgb2hsv(img);

bins{1} = [-inf 0.2 0.5 0.7:0.04:0.95 inf];
bins{2} = [-inf 0.1:0.1:0.9 inf];
bins{3} = [-inf 0.1:0.1:0.9 inf];

[dump numRegions] = bwlabel(imgRegions,4);

[xGrad yGrad] = gradient(hsvimg(:,:,3));
gradImg = sqrt(xGrad.^2 + yGrad.^2);
gradBins{1} = [0:0.1:0.6 inf];

bins{4} = gradBins{1};
hsvimg(:,:,4) = gradImg;

trainProps = [];
if(numRegions==0)
  return;
end
for funcNo = 1:length(biopsyTopFunctions)
  if(isempty(trainProps))
    trainProps = eval(biopsyTopFunctions{funcNo});
  else
    tempProps = eval(biopsyTopFunctions{funcNo});
    trainProps = joinFields(trainProps,tempProps);
  end
end

