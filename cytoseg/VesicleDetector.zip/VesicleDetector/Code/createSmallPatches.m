function createSmallPatches(imgName)

patches = readAnnFile(imgName);
iter = findIteration('top');
kk = sprintf('load ../images/biopsies/top_scores/score_iter%d_%s.mat',iter,imgName);
eval(kk);
boxSize = 60;
blockSize = 2*boxSize;
imgFileName = sprintf('../images/biopsies/whole/%s.jpg', imgName);
img = imread(imgFileName);
type = {'gland','cancer','grade5'};

for ndx=1:length(patches)
  if strcmp(patches(ndx).ann,'Predicted'); continue;end;
  curPatch = img(patches(ndx).y:patches(ndx).y+blockSize,...
    patches(ndx).x:patches(ndx).x+blockSize,:);
  for k=1:length(type)
      scorePatch = allPropsImg(patches(ndx).y:patches(ndx).y+blockSize,...
         patches(ndx).x:patches(ndx).x+blockSize,k);
      clear outLine;
      outLine(:,:,1) = zeroCrossings( (scorePatch>0)-0.5);
    outLine(:,:,2) = zeroCrossings( (scorePatch<0)-0.5);
    cimg = drawOutline(curPatch,outLine,[0 255 0 ; 255 0 0]');
    fileName = sprintf('../images/biopsies/smallPatches/%s_%d_%d_%s.png',...
       imgName,patches(ndx).x,patches(ndx).y,type{k});
    imwrite(cimg,fileName);
  end
  
end