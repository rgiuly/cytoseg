function geomProperties = geomProps(regions)

[lab ncomp] = bwlabel(regions,4);

geomProperties = regionprops(lab,{'Area','Perimeter','Solidity','Eccentricity','MinorAxisLength'});

for i=1:ncomp
  geomProperties(i).AreaByPerim = geomProperties(i).Area/(geomProperties(i).Perimeter+1)^2;
end
