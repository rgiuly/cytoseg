function out = outlinePos(scores)

out = ~zeroCrossings((scores>0)-0.5);