function trainProps = biopsyProps(type,imgName,iter)

tic;
evalStr = sprintf('load ../images/biopsies/%s_labels/iter_%d_label_%s',type,iter,imgName);
eval(evalStr);

imgFileName = sprintf('../images/biopsies/%s.jpg',imgName);
img = imread(imgFileName);
img = double(img);

imgPosProps = biopsyGetProps(type,img,imgPos,1);
imgNegProps = biopsyGetProps(type,img,imgNeg,1);

trainProps = [];
if(~isempty(imgPosProps))
  trainProps = [trainProps;imgPosProps];
end
if(~isempty(imgNegProps));
  trainProps = [trainProps;imgNegProps];
end

evalStr = sprintf('save ../images/biopsies/%s_training_props/iter_%d_ training_props_%s trainProps',type,iter,imgName);
eval(evalStr);
toc;
