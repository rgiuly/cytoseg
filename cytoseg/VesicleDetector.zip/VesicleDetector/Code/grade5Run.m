doLearn =1;
doClassify = 1;
doLabel = 0;
imgNo = [43 44 51 57 59 66 68 82 85 91 100 102 114 117];
types = {'gland','cancer','grade5'};%'cancer'};%,'grade5','gland'};

if(doLearn>0)
  for jj = 1:length(types)
    biopsyBoostLearn(types{jj});
  end
end

imgNames = {};
for cc=1:length(imgNo)
  imgRoot = sprintf('TI%03d',imgNo(cc));
  tt = sprintf('../images/biopsies/%s*',imgRoot);
  allImages = dir(tt);

  for i=1:length(allImages)
    imgNames{end+1} = allImages(i).name(1:end-4);
  end
end

if(doClassify>0);
  for jj = 1:length(types)
    for ii = 1:length(imgNames);
      biopsyClassify(types{jj},imgNames{ii});
    end
  end
end

if(doLabel>0);
  for ii = 1:length(imgNames);
    for jj = 1:length(types)
      fprintf('For type: %s\n',types{jj});
      biopsyLabelImg(types{jj},imgNames{ii});
    end
  end
end


%%%% Correct labels %%%%%


type = 'cancer';
biopsyBoostLearn(type);

xx = dir(['../images/biopsies/' type '_labels/']);

for i=length(xx):-1:1
  if xx(i).isdir; continue; end;
  imgName = char(xx(i).name(1:end-10));

  fprintf('Props image: %s  .. ',imgName);
%   biopsyCorrectLabel(type,imgName);
   biopsyClassify(type,imgName);
%   biopsyLabelImg(type,imgName);
%   biopsyCheckMismatch(type,imgName);
end



%%%% For TOP LEVEL %%%%
images = {'tinyImage099_3','tinyImage008_2','tinyImage004_2',...
    'tinyImage022_1','tinyImage040_1','tinyImage088_3','tinyImage092_1',...
};

for imgNo = 1:length(images)
  biopsyTopClassify(images{imgNo},1);
end

images = {'tinyImage109_1','tinyImage001_3','tinyImage005_2',...
    'tinyImage097_3','tinyImage086_1','tinyImage010_1','tinyImage010_2'};

%%%% Other run for top level %%%%
for imgNo = 1:length(images)
  biopsyTopClassify(images{imgNo},2);
end

%%% On all images..

images = {'tinyImage010_1','tinyImage012_1','tinyImage013_1',...
  'tinyImage015_1','tinyImage016_1','tinyImage017_1','tinyImage018_1',...
  'tinyImage019_1',};


for imgNo = 1:length(images)
  biopsyTopClassify(images{imgNo},1);
end

imgDir = dir('../images/biopsies/whole/*.jpg');
for imgNo = 1:length(imgDir)
  biopsyTopClassify(imgDir(imgNo).name(1:end-4),2);
end

imgDir = dir('../images/biopsies/whole/*.jpg');
for imgNo = 2:length(imgDir)
  biopsyTopClassify(imgDir(imgNo).name(1:end-4),2);
end
