function biopsyCheckMismatch(type,imgName)

% function biopsyLabelImg(type,imgName,blk)
% To relabel part of images and get more data for classification.
% iter is the iteration using which classification was done.
% Labels will be generated for next iteration.


iter = findIteration(type);

blk = 3000;

tic;
fprintf('Working on Image %s\n',imgName);

img = imread(['../images/biopsies/' imgName '.jpg']);
[h w d] = size(img);


eval(['load ../images/biopsies/' type '_scores/score_iter' num2str(iter) '_' imgName]);

labelFile = sprintf('../images/biopsies/%s_labels/%s_label.mat',type,imgName);
if (exist(labelFile,'file'))
  eval(sprintf('load %s',labelFile));
else
  imgPos = false(h,w);
  imgNeg = false(h,w);
end

for hh=1:blk:h
  for ww=1:blk:w
    hhEnd = min(hh+blk-1,h); wwEnd = min(ww+blk-1,w);

    if(sum(sum(scoreImg(hh:hhEnd,ww:wwEnd)>0 & imgNeg))==0 && ...
        sum(sum(scoreImg(hh:hhEnd,ww:wwEnd)<0 & imgPos))==0); 
      break;
    end
    [timgNeg timgPos] = relabelRegions(img(hh:hhEnd,ww:wwEnd,:),...
      scoreImg(hh:hhEnd,ww:wwEnd)>0 & imgNeg ,scoreImg(hh:hhEnd,ww:wwEnd)<0 & imgPos,blk);

  
    if( sum(sum(timgPos & imgNeg(hh:hhEnd,ww:wwEnd)))>0 || ...
        sum(sum(timgNeg & imgPos(hh:hhEnd,ww:wwEnd)))>0)
      fprintf('Same Regions different labels. Ignoring both labels\n');
      
      misMatch = timgPos & imgNeg(hh:hhEnd,ww:wwEnd);
      timgPos = timgPos & ~misMatch;
      imgNeg(hh:hhEnd,ww:wwEnd) = imgNeg(hh:hhEnd,ww:wwEnd) & ~misMatch;

      misMatch = timgNeg & imgPos(hh:hhEnd,ww:wwEnd);
      timgNeg = timgNeg & ~misMatch;
      imgPos(hh:hhEnd,ww:wwEnd) = imgPos(hh:hhEnd,ww:wwEnd) & ~misMatch;
      
    end
      
    imgPos(hh:hhEnd,ww:wwEnd) = imgPos(hh:hhEnd,ww:wwEnd) | timgPos;
    imgNeg(hh:hhEnd,ww:wwEnd) = imgNeg(hh:hhEnd,ww:wwEnd) | timgNeg;

  end
end

evalStr = sprintf('save ../images/biopsies/%s_labels/%s_label imgPos imgNeg', type, imgName);
eval(evalStr);
