function boostDirName = makeBoostDir(type,iter)
% function makeBoostDir(type,iter);

boostDirName = sprintf('../%s_boost/biopsies/iter_%d',type,iter);
if(~exist(boostDirName,'dir'));mkdir(boostDirName);end
