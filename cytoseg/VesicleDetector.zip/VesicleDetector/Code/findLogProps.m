function props = findLogProps(filtimg,regions,extraStr,bins)
% function props = findLogProps(filtimg,regions,extraStr)
% Finds histogram properties of inside regions.
% Log in name is for historical reasons.

% binEdges = [-inf 0.1:0.1:0.9 inf];
% binHueEdges = [-inf 0.2 0.5 0.7:0.04:0.95 inf];

[lab ncomp] = bwlabel(regions,4);
  
for j=1:size(filtimg,3);
  for i=1:length(bins{j})-1
    dummyStruct.(['log_' num2str(j) '_' extraStr '_dim_' num2str(i)]) = 0;
  end
end

props = repmat(dummyStruct,[ncomp 1]);

areaAll = regionprops(lab,'Area');

if(ncomp>0)
  for j = 1:size(filtimg,3)
    for i=1:length(bins{j})-1
      tempLab = lab.*( (filtimg(:,:,j)>bins{j}(i)) & (filtimg(:,:,j)<bins{j}(i+1)));
      tempLab(end,end)=ncomp+1;    % to handle the corner cases :)
      tprops = regionprops(tempLab ,'Area');
      tprops = tprops(1:end-1);
      for k=1:ncomp
        tprops(k).Area = tprops(k).Area/areaAll(k).Area;
      end
      [props(:).(['log_' num2str(j) '_' extraStr '_dim_' num2str(i)])] = (tprops(:).Area);
    end
  end
end

