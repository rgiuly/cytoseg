function showResults(img,allPropsImg,x,y)

% function showResults(img,allProsImg,x,y)

qq = allPropsImg(y,x,1);
aData = double(~(qq==0 | isinf(qq)));
qq(qq<-10)=-10; qq(qq>9.9)=9.9;
qq = (qq+10)/20;
ss = ind2rgb(ceil((qq+0.01)*64),jet(64));
aData(aData==1)=0.5;
figure; imshow(img(y,x,:));
hold on;
ii = imshow(ss);
set(ii,'AlphaData',aData);axis image

gg = ~outlinePos(allPropsImg(y,x,1));
gg(:,:,2) = ~outlinePos(-allPropsImg(y,x,1));
figure; imshow(drawOutline(img(y,x,:),gg,[0 255 0; 255 0 0]'));

qq = allPropsImg(y,x,2);
aData = double(~(qq==0 | isinf(qq)));
qq(qq<-10)=-10; qq(qq>9.9)=9.9;
qq = (qq+10)/20;
ss = ind2rgb(ceil((qq+0.01)*64),jet(64));
aData(aData==1)=0.5;
figure; imshow(img(y,x,:));
hold on;
ii = imshow(ss);
set(ii,'AlphaData',aData);axis image

gg = ~outlinePos(allPropsImg(y,x,2));
gg(:,:,2) = ~outlinePos(-allPropsImg(y,x,2));
figure; imshow(drawOutline(img(y,x,:),gg,[0 255 0; 255 0 0]'));

qq = allPropsImg(y,x,3);
aData = double(~(qq==0 | isinf(qq)));
qq(qq<-10)=-10; qq(qq>9.9)=9.9;
qq = (qq+10)/20;
ss = ind2rgb(ceil((qq+0.01)*64),jet(64));
aData(aData==1)=0.5;
figure; imshow(img(y,x,:));
hold on;
ii = imshow(ss);
set(ii,'AlphaData',aData);axis image

gg = ~outlinePos(allPropsImg(y,x,3));
gg(:,:,2) = ~outlinePos(-allPropsImg(y,x,3));
figure; imshow(drawOutline(img(y,x,:),gg,[0 255 0; 255 0 0]'));
