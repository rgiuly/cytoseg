function vectorizePredictor(type,curIter)
% function vectorizePredictor(type,curIter);

predFileName = sprintf('predictors/%s_predict_iter%d.m',type,curIter);
copyfile(['../' type '_boost/biopsies/iter_' num2str(curIter) '/predict.m'],predFileName);
sysCmd = sprintf('python ../python/vectorizePredictor.py %s',predFileName);
system(sysCmd);
