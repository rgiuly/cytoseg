function biopsyTopLearn(tempNo)
% function biopsyTopLearn
% copies the old annotation file to oldAnnotations/imgName.orig.iterNo.jpg.ann
% imgName.jpg.ann is cleaned (All predicted boxes are removed)

%%% Find the iteration number

curIter = findIteration('top')+1;
fprintf('\n\n Iteration %d\n ..\n\n',curIter);

xx = dir('../images/biopsies/whole/');
xx = flipud(xx);

% Find the properties..
boxSize = 60;
blockSize = 2*boxSize;
maxPad = boxSize;
propsBins{1} = [-inf -10 -5 -1 0 1 5 10 inf];
propsBins{2} = [-inf -10 -5 -1 0 1 5 10 inf];
propsBins{3} = [-inf -10 -5 -1 0 1 5 10 inf];

prevRunFile = sprintf('../images/biopsies/topLearn.mat');
if (exist(prevRunFile,'file'))
  eval(['load ' prevRunFile]);
else
  prevRunIter = 0;
end

if(prevRunIter ~= curIter)
  allProps = [];
  locs = {};
  imagesDone.('dummy') = 1;
  prevRunIter = curIter;
end

for i=1:length(xx)
  if xx(i).isdir; continue; end;
  if isempty(strfind(xx(i).name,'.ann')); continue; end;
  if (strfind(xx(i).name,'.ann.')); continue; end; %% For backup files
  imgName = char(xx(i).name(1:end-8));
  if(isfield(imagesDone,imgName)); continue;end; % Was completed in previous Run

  fprintf('   Props image: %s  .. ',imgName);
  t1 = clock;
  
  cleanAnnFile(imgName,curIter);
  patches = readAnnFile(imgName);
  
  img = imread(['../images/biopsies/whole/' imgName '.jpg']);
  img(end+1:end+blockSize,:,:)=255;
  img(:,end+1:end+blockSize,:)=255;
  [h w d]=size(img);
  
  for patchNo = 1:length(patches)
    if strcmp(patches(patchNo).ann,'Observe') || strcmp(patches(patchNo).ann,'Predicted')  
       continue;
    end
    curPatchX = patches(patchNo).x+1;
    curPatchY = patches(patchNo).y+1;
    curPatchLabel = patches(patchNo).label;
    
    padding = findPadding(curPatchX,curPatchY,w,h,maxPad,blockSize);
    
    tempImg = img(curPatchY-padding(1):curPatchY+blockSize-1+padding(3),...
      curPatchX-padding(2):curPatchX+blockSize-1+padding(4),:);
    imwrite(tempImg,sprintf('../images/biopsies/temp%d.jpg',tempNo),'jpg');
  
    tempImgName = sprintf('temp%d',tempNo);
    clear propsImg;
    propsImg(:,:,1) = biopsyClassify('gland',tempImgName,1);
    propsImg(:,:,2) = biopsyClassify('cancer',tempImgName,1);
    propsImg(:,:,3) = biopsyClassify('grade5',tempImgName,1);
    curProps = propsImg(padding(1)+1:end-padding(3),padding(2)+1:end-padding(4),:);

    tempImg = img(curPatchY:curPatchY+blockSize-1,curPatchX:curPatchX+blockSize-1,:);
    allProps = [allProps; ...
      topGetProps(tempImg,curPatchLabel,curProps,propsBins);];
    locs{end+1}=sprintf('%s_%d_%d',imgName,curPatchY,curPatchX);
  end

  t2 = clock;
  fprintf('   Time for Image %s with %d patches: %.1f secs\n',...
    imgName,length(patches),etime(t2,t1));
  imagesDone.('imgName')=1;
  save ../images/biopsies/topLearn.mat imagesDone prevRunIter allProps locs;
end

allProps = addRandomIndex(allProps);

makeBoostDir('top',curIter);
writeLocsFile('top',allProps,locs,curIter);

boostLearn(['../top_boost/biopsies/iter_' num2str(curIter)],allProps);
vectorizePredictor('top',curIter);