function timg = overlay(img, selectedPixels,valsToUse)

% function overlay(img, selectedPixels)

if(nargin<3)
  timg = img.*repmat(uint8(selectedPixels), [1 1 size(img,3)]);
  figure; imshow(timg);
  axis on;
else
  for i=1:size(img,3)
    tt = img(:,:,i);
    for j=1:size(selectedPixels,3)
       tt(selectedPixels(:,:,j)) = valsToUse(j,i);
       timg(:,:,i) = tt;
    end
  end
  figure; imshow(timg);
end
