imgName = '39p2';

close all

img = imread(sprintf('../images/biopsies/%s.jpg',imgName));
eval(sprintf('load ../images/biopsies/all_scores/score_iter18_%s.mat',imgName));

[x y] = markVescicles(img);

eval(sprintf('save trueLabels%s x y',imgName));
locs = sub2ind(size(img),y,x);
zz = scoreImg(locs);

gg = zeros(size(img));
for ndx =1:length(zz)
    if(zz(ndx)>0); continue; end;
    gg(y(ndx),x(ndx))=1;
end

gg = imdilate(gg,strel('disk',9));
overlay(img,~zeroCrossings(gg-0.5));
title('Missed');

pp = zeros(size(img));
pp(locs)=1;
pp = imdilate(pp,strel('disk',9));
overlay(img, ~zeroCrossings(pp-0.5));
title('Marked');

%%% To show the colored image.
clear tt;
tt(:,:,1) = zeroCrossings(imdilate(scoreImg>0,strel('disk',8))-0.5);
tt(:,:,2) = zeroCrossings((scoreImg>0)-0.5);
qq = img;
qq = repmat(qq,[1 1 3]);
ff = qq(:,:,1);
ff(tt(:,:,1))= 0;
ff(tt(:,:,2))= 255;
qq(:,:,1) = ff;
ff = qq(:,:,2);
ff(tt(:,:,1))= 255;
ff(tt(:,:,2))= 0;
qq(:,:,2) = ff;
ff = qq(:,:,3);
ff(tt(:,:,2))= 0;
ff(tt(:,:,1))= 0;
qq(:,:,3) = ff;
figure; imshow(qq)

[d1 d2]= bwlabel(scoreImg>0,4);
fprintf('True/Marked:%d True/Missed:%d  Total Marked:%d\n',sum(zz>0),sum(zz<=0),d2);
