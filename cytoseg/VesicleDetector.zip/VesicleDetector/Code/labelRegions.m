function [selPos selNeg] = labelRegions(img,imgLabels,blockSize)

% function [selPos selNeg] = labelRegions(img,imgLabels,blockSize)
% displays image as 1000x1000 blocks 
% use relabelRegions to correct.


imgComp = imgLabels>0;
imgEdge = imdilate(imgComp,strel('disk',1))-imgComp;
[h w] = size(imgComp);
selPos = false([h w]);
selNeg = false([h w]);

if(ndims(img)==2)
  img=repmat(img,[1 1 3]);
end

if(nargin<3); blockSize = 1000; end;

figno = figure;

for i=1:blockSize:h
for j=1:blockSize:w
  maxi = min(i+blockSize-1,h); maxj = min(j+blockSize-1,w);
  
  tselPos = selPos(i:maxi,j:maxj);
  tselNeg = selNeg(i:maxi,j:maxj);
  timgLabels = imgLabels(i:maxi,j:maxj);
  timg = img(i:maxi,j:maxj,:);
  timgEdge = uint8(imgEdge(i:maxi,j:maxj));
  timg = timg+255*repmat(timgEdge,[1 1 3]);  % White edge.
  
  % Get positive regions.
  figure(figno); imshow(timg); title('Mark Positive');
  [xi,yi] = getpts;
  c = round(axes2pix(size(timg,2), [1 size(timg,2)], xi));
  r = round(axes2pix(size(timg,1), [1 size(timg,1)], yi));
  locations = sub2ind(size(timgLabels),r,c);

  tselCompLab = timgLabels(locations);
  tselCompLab = setdiff(tselCompLab,0);
  tselPos = tselPos | ismember(timgLabels,tselCompLab);
  timgPosEdge = uint8(imdilate(tselPos, strel('disk',1)) & (~tselPos));

  % Green Edge for pos.
  timg(:,:,1) = timg(:,:,1)-255*timgPosEdge;
  timg(:,:,2) = timg(:,:,2)+255*timgPosEdge;
  timg(:,:,3) = timg(:,:,3)-255*timgPosEdge;

  figure(figno); imshow(timg); title('Mark Negative');
  [xi, yi] = getpts;
  c = round(axes2pix(size(timg,2), [1 size(timg,2)], xi));
  r = round(axes2pix(size(timg,1), [1 size(timg,1)], yi));
  locations = sub2ind(size(timgLabels),r,c);

  tselCompLab = timgLabels(locations);
  tselCompLab = setdiff(tselCompLab,0);
  tselNeg = tselNeg | ismember(timgLabels,tselCompLab);
  timgNegEdge = uint8(imdilate(tselNeg,strel('disk',1)) & (~tselNeg));

  
  % Red edge for neg
  timg(:,:,1) = timg(:,:,1)+255*timgNegEdge;
  timg(:,:,2) = timg(:,:,2)-255*timgNegEdge;
  timg(:,:,3) = timg(:,:,3)-255*timgNegEdge;
  
  % Yellow edge for common edges.
  timgBothEdge = uint8(timgNegEdge & timgPosEdge);
  timg(:,:,1) = timg(:,:,1)+255*timgBothEdge;
  timg(:,:,2) = timg(:,:,2)+255*timgBothEdge;
  timg(:,:,3) = timg(:,:,3)-255*timgBothEdge;

  figure(figno); imshow(timg); title('Green Positive, Red Negative, Yellow Both');
  [xi yi]=getpts;
  
  selPos(i:maxi,j:maxj)=tselPos;
  selNeg(i:maxi,j:maxj)=tselNeg; 

end
end

close(figno);
