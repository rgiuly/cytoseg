function patchList = findUniquePatches(pixPatch,scale)

% function patchList = findUniquePatches(pixPatch,scale)
% Localizes patches

blabel = bwlabel(pixPatch>0);
meds = regionprops(blabel,pixPatch,'MaxIntensity');
patchList = [];

for ndx=1:length(meds)
  curMax = meds(ndx).MaxIntensity;
  tt = (blabel==ndx)&(pixPatch>=curMax);
  [maxT,ind] = max(tt(:));
  [curY,curX] = ind2sub(size(tt),ind);
  patchList=[patchList;curX*scale curY*scale];
  
end