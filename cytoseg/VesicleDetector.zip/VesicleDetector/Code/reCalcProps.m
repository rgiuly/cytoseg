function reCalcProps(type)

files = dir(['../images/biopsies/' type '_labels/']);
maxIter = 0;
for i=1:length(files)
  yy=[];
  yy = sscanf(files(i).name,'iter_%d_label_%s');
  if(isempty(yy)); continue; end
  iterNo = yy(1);
  imgName = char(yy(2:end-4)');
  biopsyProps(type,imgName, iterNo);
  if(maxIter<iterNo)
    maxIter = iterNo;
  end
end

biopsyBoostLearn(type,maxIter);
  
