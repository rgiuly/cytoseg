function contourImg = biopsyFindOutline(type,imgName,offset,dim2use,ss)

% function biopsyFindOutline(type,imgName,offset,dim2use,ss)
% recommended offset is 0.0002 for grade5 and -0.001 for others.
% dim2use is 1 for grade5 and 3 for others.



offset = 0.0015; dim2use = 1;ss = 2;

if(nargin==3);
  fprintf('Not the correct usage\n'); return;
end



blk = 1000;

img = imread(['../images/biopsies/' imgName '.jpg']);
[h w d] = size(img);

contourImg = zeros(h,w);

for hh=1:blk:h
  for ww=1:blk:w
    hh_end = min(hh+blk-1,h); ww_end = min(ww+blk-1,w);
    hsvimg = double(img(hh:hh_end,ww:ww_end,:));
    hsvimg = hsvimg-min(hsvimg(:));
    hsvimg = hsvimg/max(hsvimg(:));
    lapimg = imfilter(hsvimg(:,:,dim2use),fspecial('log',(2*ceil(3*ss))+1,ss));
    contourImg(hh:hh_end,ww:ww_end) = zeroCrossings(lapimg-offset);
  end
end

