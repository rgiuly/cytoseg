function allProps = addRandomIndex(allProps);
% function allProps = addRandomIndex(allProps);

randNdx = randperm(length(allProps));
for ndx = 1:length(allProps)
  allProps(ndx).INDEX = randNdx(ndx);
end

