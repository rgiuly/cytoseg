function finalStruct = joinFields(varargin)


if(nargin<2); fprintf('Give atleast 2 arguments\n'); return; end;


nexamples = length(varargin{1});

for i=2:nargin
  if(length(varargin{i})~=nexamples);
    fprintf('All the inputs are not of same size\n'); return;
  end
end

nfields = zeros(nargin,1);
argFields = {};
for i=1:nargin
  argFields = [argFields; fieldnames(varargin{i})];
  nfields(i) = length(fieldnames(varargin{i}));
end


finalCell = cell(sum(nfields(:)),nexamples);

fieldsDone =0;
for i=1:nargin
  finalCell(fieldsDone+1:fieldsDone+nfields(i),:) = struct2cell(varargin{i});
  fieldsDone = fieldsDone + nfields(i);
end

finalStruct = cell2struct(finalCell, argFields, 1);
