function biopsyInitialize(type,imgName)
% function biopsyInitialize(type,imgName)

imgFileName = sprintf('../images/biopsies/%s.jpg',imgName);
img = imread(imgFileName);

offset = 0.0015; dim2use = 1;ss=2;

hsvimg = double(img);
hsvimg = hsvimg-min(hsvimg(:));
hsvimg = hsvimg/max(hsvimg(:));
lapimg = imfilter(hsvimg(:,:,dim2use),fspecial('log',2*ceil(3*ss)+1,ss));
kk = zeroCrossings(lapimg-offset);

[imglab, numRegions] = regionsFromEdges(kk);
[imgPos imgNeg] = labelRegions(img,imglab,2000);
savefilecmd = sprintf('save ../images/biopsies/%s_labels/%s_label.mat imgPos imgNeg',type,imgName);
eval(savefilecmd);
