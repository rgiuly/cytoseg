function biopsyBoostLearn(type)
% function biopsyBoostLearn(type)


xx = dir(['../images/biopsies/' type '_labels/']);

% Find the properties..

allProps = [];
locs = {};
for i=1:length(xx)
  if xx(i).isdir; continue; end;
  imgName = char(xx(i).name(1:end-10));

  fprintf('Props image: %s  .. ',imgName);
  tic;
  
  evalStr = sprintf('load ../images/biopsies/%s_labels/%s',type,xx(i).name);
  eval(evalStr);
  img = imread(['../images/biopsies/' imgName '.jpg']);
  
  clear glandPropsImg;
  if(strcmp(type,'cancer'))
    glandPropsImg = biopsyClassify('gland',imgName);
    glandPropsBin{1} = [-inf -0.01 0.01 inf];
  elseif(strcmp(type,'grade5'));
    glandPropsImg(:,:,1) = biopsyClassify('gland',imgName);
    glandPropsBin{1} = [-inf -0.01 0.01 inf];
    glandPropsImg(:,:,2) = biopsyClassify('cancer',imgName);
    glandPropsBin{2} = [-inf -0.01 0.01 inf];
  else
    glandPropsImg = [];
    glandPropsBin{1}=[];
  end

  allProps = [allProps; ...
    biopsyGetProps(img,imgPos,1,glandPropsImg,glandPropsBin); ...
    biopsyGetProps(img,imgNeg,-1,glandPropsImg,glandPropsBin);];
  
  %%% Find the location for each data point
  tempLabs = bwlabel(imgPos,4);
  centroidLocs = regionprops(tempLabs,'centroid');
  for nndx = 1:length(centroidLocs)
    locs{end+1} = sprintf('%s_%.1f_%.1f',imgName,centroidLocs(nndx).Centroid(1),...
      centroidLocs(nndx).Centroid(2));
  end
  tempLabs = bwlabel(imgNeg,4);
  centroidLocs = regionprops(tempLabs,'centroid');
  for nndx = 1:length(centroidLocs)
    locs{end+1} = sprintf('%s_%.1f_%.1f',imgName,centroidLocs(nndx).Centroid(1),...
      centroidLocs(nndx).Centroid(2));
  end
  %%% Done with location.

  toc;
end

allProps = addRandomIndex(allProps);

curIter = findIteration(type)+1;
boostDirName = makeBoostDir(type,curIter);
writeLocsFile(type,allProps,locs,curIter);

boostLearn(boostDirName,allProps);
%vectorizePredictor(type,curIter);
