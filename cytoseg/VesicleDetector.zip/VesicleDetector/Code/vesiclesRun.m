%%%% Vesicle detector by Mayank %%%%%%

%%%%  Setup:
%%%%  Install jboost. Available at http://jboost.sourceforge.net/
%%%%  Make sure you can run jboost as a "system" command in matlab.
%%%%  You can tested it by running the following command in an example
%%%%  directory.
%%%%  system('java -Xmx1500M jboost.controller.Controller -CONFIG example_file_config'); 
%%%%

%%%% Run all the commands from the directory in which this file resides.

%%%% Images should be in ../images/biopsies/
%%%% Images should be rescaled by a factor of 4.
%%%% Image names should end with .jpg
%%%% Image names to be used in command should not have the .jpg extension.

%%% We use iterative learning where we correct mistakes made by the
%%% classifier. We do this till we are happy of performance on test images.

%%% To start the iterative learning we mark some positives and negatives
%%% in an image. The commands are as follows.

%%% We start by labeling image '00p1.jpg' as follows.

biopsyInitialize('all','00p1');

%%% First you mark some regions that are vesicles. Click within a
%%% region.
%%% Once done press enter.
%%% Then you mark some regions that are not vesicles again by clicking
%%% within such regions.
%%% Once done press enter.
%%% Once done you'll can review the regions that you have labeled. Click
%%% enter to finish.

%%% Once done with labeling we learn a classifier.

biopsyBoostLearn('all');

%%% After learning the classifier we classify few images.

images = {'00p1','00p2','01p1'};
for imgNo = 1:length(images)
  biopsyClassify('all',images{imgNo});
end


%%%% We then review how the classifiers performance and correct mistakes.
%%%% Correct classifiers mistakes by clicking inside regions that were
%%%% marked incorrectly by the classifier. You don't have to correct all
%%%% the mistakes. Correcting a few should suffice.
%%%% Once you are done press enter. If you are satisfied with the
%%%% corrections, press enter without clicking.

for imgNo = 1:length(imges)
    img = imread('../images/biopsies/%02dp%d.jpg',images{imgNo});
    figure; imshow(img);
    biopsyLabelImg('all',images{imgNo});  
end


%%%% We then retrain the classifier.

biopsyBoostLearn('all');

%%%%% Repeat the above steps of classify, labeling and learning till
%%%%% satisfied. Around 10-15 iterations should be OK.


%%% Once satisfied with the performance, you can output the xml file with
%%% squares marking the vesicles.

for imgNo = 1:length(images)
    iter = findIteration('all');
    eval(sprintf('load ../images/biopsies/all_scores/score_iter%d_%s'...
        ,iter,images{imgNo}));
    ff = fopen(sprintf('../images/biopsies/result%s.xml',...
        images{imgNo}),'w');
    fprintf(ff,'<?xml version=\"1.0\" ?>\n<main>\n');

    [h w] = size(scoreImg);
    ll = bwlabel(scoreImg>0,4);
    ss = regionprops(ll,'BoundingBox');
    str = '';
    for blkNo=1:length(ss)
        bbox = ss(blkNo).BoundingBox;
        fprintf(ff,'<contour class=\"Vesicle\" identifier=\"Predicted\" closed=\"true\">\n');
        fprintf(ff,'<points>\n');
        fprintf(ff,'%.1f, %.1f, 0, ',bbox(1)-8,bbox(2)-8);% ul
        fprintf(ff,'%.1f, %.1f, 0, ',bbox(1)+bbox(3)+8,bbox(2)-8);% ur
        fprintf(ff,'%.1f, %.1f, 0, ',bbox(1)+bbox(3)+8,bbox(2)+bbox(4)+8);%lr
        fprintf(ff,'%.1f, %.1f, 0 ',bbox(1)-8,bbox(2)+bbox(4)+8);%ll
        fprintf(ff,'</points>\n');
        fprintf(ff,'</contour>\n');
    end
    fprintf(ff,'</main>\n');
    fclose(ff);
end

