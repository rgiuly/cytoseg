function selRegions = biopsySelRegions(hsvimg)

% function selRegions = biopsySelRegions(hsvimg);
% Finds tissue regions using saturation.

satRegions = hsvimg(:,:,2)>0.2;
lab = bwlabel(~satRegions,4);
areaProps = regionprops(lab,'Area');
smallHolesIdx = find([areaProps.Area]<5000);
smallHoles = ismember(lab,smallHolesIdx);
selRegions = satRegions | smallHoles;