function trainProps = biopsyGetProps(img,imgRegions,curLabel,extraImg,extraImgBins)
% finds features for biopsy images 

biopsyFunctions = {'findRegionProps(hsvimg,imgRegions)',...
        sprintf('findLogProps(hsvimg,imgRegions,\''hist\'',bins)'),...
        sprintf('findExternalEdgeProps(hsvimg,imgRegions,dFactors,bins,selRegions)'),...
        sprintf('findInternalEdgeProps(hsvimg,imgRegions,2,bins)'),...
        sprintf('findInternalEdgeProps(hsvimg,imgRegions,4,bins)'),...
        'geomProps(imgRegions)',...
         'labelProps(numRegions,curLabel)',...
       };


dFactors = [2,4,7,10,25,50];
hsvimg = double(img);
hsvimg = hsvimg-min(hsvimg(:));
hsvimg = hsvimg/max(hsvimg(:));
hsvimg = repmat(hsvimg,[1 1 3]);

bins{1} = [-inf 0.2 0.5 0.7:0.04:0.95 inf];
bins{2} = [-inf 0.1:0.1:0.9 inf];
bins{3} = [-inf 0.1:0.1:0.9 inf];

[dump numRegions] = bwlabel(imgRegions,4);
selRegions = ones(size(img));

[xGrad yGrad] = gradient(hsvimg(:,:,3));
gradImg = sqrt(xGrad.^2 + yGrad.^2);
gradBins{1} = [0:0.1:0.6 inf];

bins{4} = gradBins{1};
hsvimg(:,:,4) = gradImg;
trainProps = [];

if(nargin>3)
  [h w d]= size(extraImg);
  if(h*w*d>0)
    hsvimg(:,:,end+1:end+d) = extraImg;
    for i=1:d
      bins{end+1}=extraImgBins{i};
    end
  end
end


if(numRegions==0)
  return;
end
for funcNo = 1:length(biopsyFunctions)
  if(isempty(trainProps))
    trainProps = eval(biopsyFunctions{funcNo});
  else
    tempProps = eval(biopsyFunctions{funcNo});
    trainProps = joinFields(trainProps,tempProps);
  end
end

