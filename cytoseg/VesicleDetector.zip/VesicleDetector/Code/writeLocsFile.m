function writeLocsFile(type,allProps,locs,curIter)

% function writeLocsFile(type,allProps,locs)

boostDirName = sprintf('../%s_boost/biopsies/iter_%d',type,curIter);
locsFile = fopen([boostDirName '/locs'],'w');
for ndx = 1:length(allProps)
  fprintf(locsFile,'%d %s %d\n',allProps(ndx).INDEX,locs{ndx},allProps(ndx).labels);
end
fclose(locsFile);
