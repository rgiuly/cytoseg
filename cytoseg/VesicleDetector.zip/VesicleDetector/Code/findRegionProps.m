function props = findRegionProps(img,regions,extraStr)


[lab ncomp] = bwlabel(regions,4);

if(nargin<3)
  extraStr = '';
end

for i=1:size(img,3)
  dummyStruct.(['mean_' num2str(i) extraStr]) = 0;
  dummyStruct.(['var_' num2str(i) extraStr]) = 0;
end
  
props = repmat(dummyStruct,[ncomp 1]);

if(ncomp==0); return; end;

for i=1:size(img,3)
  tprops = regionprops(lab,img(:,:,i),'MeanIntensity');
  [props(:).(['mean_' num2str(i) extraStr])] = tprops(:).MeanIntensity;
  
  dump = [tprops(:).MeanIntensity];
  dump = [0 dump]; meanImg = dump(lab+1);
  varImg = img(:,:,i)-meanImg;
  tprops = regionprops(lab,varImg.^2,'MeanIntensity');
  [props(:).(['var_' num2str(i) extraStr])] = tprops(:).MeanIntensity;
  
end