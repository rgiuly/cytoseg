function [labRegions, ncomp] = regionsFromEdges(edgeImg)

fillImg = imfill(edgeImg,4,'holes');
[labRegions ncomp] = bwlabel(fillImg & ~edgeImg,4);

labArea = regionprops(labRegions,'Area');
largeArea = find(([labArea.Area]>4) & ([labArea.Area]<5000));

newRegions = ismember(labRegions,largeArea);

[labRegions ncomp] = bwlabel(newRegions,4);

