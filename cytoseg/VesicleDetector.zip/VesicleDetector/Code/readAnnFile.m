function patches = readAnnFile(imgName)

% function patches = readAnnFile(imgName)

  annFileName = sprintf('../images/biopsies/whole/%s.jpg.ann', imgName);
  patches = [];
  if(~exist(annFileName,'file'));return; end
  annFile = fopen(annFileName,'r');
  C = textscan(annFile,'%s %d %d %s','CommentStyle','%');
  for i=1:length(C{1})
    patches(end+1).x = C{2}(i);
    patches(end).y = C{3}(i);
    patches(end).ann = C{4}(i);
    if strcmp(patches(i).ann,'Positive')
      patches(end).label = +1;
    elseif strcmp(patches(i).ann,'Negative')
      patches(end).label = -1;
    end
      
  end
  fclose(annFile);
