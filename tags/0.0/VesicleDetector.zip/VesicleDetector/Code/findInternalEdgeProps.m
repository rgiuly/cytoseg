function props = findInternalEdgeProps(img,regions,dFactor,bins)

[lab ncomp] = bwlabel(regions,4);
[h w d] =size(img);

for i=1:size(img,3)

  dummyStruct.(['int_mean_' num2str(i) '_' num2str(dFactor)]) = 0;
  dummyStruct.(['int_var_' num2str(i) '_' num2str(dFactor)]) = 0;

  for binNo = 1:length(bins{i})-1
      varName = ['int_hist_' num2str(i) '_' num2str(dFactor) '_bin_' num2str(binNo)];
      dummyStruct.(varName) = 0;
  end

end
  
props = repmat(dummyStruct,[ncomp 1]);

if(ncomp==0); return; end;

bbprop = regionprops(lab,'BoundingBox');
dd = strel('disk',dFactor);

for ndx=1:ncomp
  ll = max(floor(bbprop(ndx).BoundingBox(1)),1);
  uu = max(floor(bbprop(ndx).BoundingBox(2)),1);
  rr = min(floor(bbprop(ndx).BoundingBox(1)+bbprop(ndx).BoundingBox(3)),w);
  bb = min(floor(bbprop(ndx).BoundingBox(2)+bbprop(ndx).BoundingBox(4)),h);
  ss = imfill(lab(uu:bb,ll:rr)==ndx,'holes');

  ssRows = size(ss,1);
  ssPack = bwpack(ss);
  erodess = bwunpack(imerode(ssPack,dd,'ispacked',ssRows),ssRows); 
  inside = xor(erodess,ss);
  
  ind = find(inside);

  if(isempty(ind)); continue; end
  
  for i=1:d
    pp = img(uu:bb,ll:rr,i);
    curVals = pp(ind);
    featureName = sprintf('int_mean_%d_%d',i,dFactor);
    props(ndx).(featureName) = mean(curVals);
    featureName = sprintf('int_var_%d_%d',i,dFactor);
    props(ndx).(featureName)= std(curVals);

    
    histVals = histc(curVals,bins{i});
    histVals = histVals./sum(histVals);
    for binNo = 1:length(bins{i})-1
      featureName = sprintf('int_hist_%d_%d_bin_%d',i,dFactor,binNo);
      props(ndx).(featureName) =...
        histVals(binNo);
    end
  end

end
