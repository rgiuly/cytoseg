function [x y ] = markVescicles(img)

figure; imshow(img);

[xi,yi] = getpts;

x = round(axes2pix(size(img,2), [1 size(img,2)], xi));
y = round(axes2pix(size(img,1), [1 size(img,1)], yi));

