% Find the results on all images and put them in a directory with todays
% date

yy = clock;
curDir = sprintf('../images/biopsies/%02d_%02d_%02d/',yy(2),yy(3),yy(1)-2000);
if(~exist(curDir,'dir'))
  mkdir(curDir);
end

images = dir('../images/biopsies/*.jpg');
types = {'gland','cancer','grade5'};
for cc = 1:length(images)
  imgName = images(cc).name;
  imgName = imgName(1:end-4);
  for typeNo = 1:length(types)
    fprintf('FOR: %s\n',types{typeNo});
    biopsyClassify(types{typeNo},imgName);
    biopsyResultImg(types{typeNo},imgName,curDir);
%      biopsyCorrectLabel(types{typeNo},imgName);
  end
end

images = dir('../images/biopsies/*.jpg');
types = {'gland','cancer','grade5'};
for cc = 1:length(images)
  imgName = images(cc).name;
  imgName = imgName(1:end-4);
  for typeNo = 1:length(types)
    biopsyWriteLabelImg(types{typeNo},imgName,curDir);
  end
end

