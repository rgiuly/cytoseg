function timg = drawOutline(img,selectedPixels,valsToUse)
% function timg = drawOutline(img,selectedPixels,valsToUse)

if(nargin<3)
  timg = img.*repmat(uint8(selectedPixels(:,:,1)), [1 1 size(img,3)]);
else
  timg = img;
  for i=1:size(img,3)
    tt = img(:,:,i);
    for j=1:size(selectedPixels,3)
       tt(selectedPixels(:,:,j)) = valsToUse(i,j);
       timg(:,:,i) = tt;
    end
  end
end
