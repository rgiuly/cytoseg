% vv = double(1-vv);

xx = imfilter(vv,fspecial('log',25,4));
bb = 4*ones(500,500);
for k = 1:2
  tic
  newBlur = zeros(500,500);
  maxm = max(abs(xx(:)));
  for i=13:484
    for j=13:484
      bb(i,j) = bb(i,j)-0.5*abs(xx(i,j))/maxm;
      gg = fspecial('gaussian',25,bb(i,j));
      newBlur(i-12:i+12,j-12:j+12) = newBlur(i-12:i+12,j-12:j+12) + vv(i,j)*gg;
    end
  end

  beep
  figure; imagesc(newBlur);
  mm = imfilter(newBlur,fspecial('laplacian'));
  figure; imagesc(mm);
  figure; imshow(zeroCrossings(mm));

  xx = mm;
  toc;
  pause;
end

