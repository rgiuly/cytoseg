function boostLearn(dirName,data)

% Does boosting in dirName with data

if(~exist(dirName,'dir')); mkdir(dirName); end

ftrain = fopen([dirName '/jboost.data'],'w');
if(ftrain < 0); fprintf('Could not create train file in directory %s for write\n', dirName); return; end;

numPos = 0;
numNeg = 0;
for ndx=1:length(data)
  if(data(ndx).labels>0)
    numPos = numPos+1;
  else
    numNeg = numNeg+1;
  end
end

numPos = numNeg/length(data);
numNeg = 1-numPos;

for ndx=1:length(data)
  if(data(ndx).labels>0)
    data(ndx).weight = numPos;
  else
    data(ndx).weight = numNeg;
  end
end

tfields = fieldnames(data);
nfields = length(tfields);
for ndx=1:length(data)
  fcur = ftrain;
  for fld=1:nfields
    if(strcmp(tfields(fld),'labels'));
      fprintf(fcur,'%d',data(ndx).(tfields{fld}));
    else
      fprintf(fcur,'%f',data(ndx).(tfields{fld}));
    end
    if(fld<nfields); fprintf(fcur,', '); else fprintf(fcur,' ;\n'); end
  end

end

fclose(ftrain);

fspec = fopen([dirName '/jboost.spec'],'w');
if(fspec < 0); fprintf('Could create spec file in directory %s for write\n', dirName); return; end;

fprintf(fspec,'exampleTerminator=;\nattributeTerminator=,\nmaxBadExa=0\n');

for fld = 1:length(tfields)
  if(strcmp(tfields(fld),'labels'))
    fprintf(fspec,'labels (-1, 1)\n');
  else
    fprintf(fspec,'%s number\n',tfields{fld});
  end
end

fclose(fspec);

fconfig = fopen([dirName '/jboost.config'],'w');
if(fconfig < 0); fprintf('Could create spec file in directory %s for write\n', dirName); return; end;

fprintf(fconfig,'-T jboost.data -t jboost.data -n jboost.spec -p 2 -b LogLossBoost -numRound 250 -ATreeType ADD_ALL -a -2 -m predict.m\n');
fclose(fconfig);

curdir = pwd;
cd(dirName);
system('java -Xmx1500M jboost.controller.Controller -CONFIG jboost.config');
cd(curdir);
fprintf('\n\n Done..\n');
