doLearn =0;
imgNo = [43 117];
type = 'gland';

if(doLearn>0)
  biopsyBoostLearn(type);
end

imgNames = {};
for cc=1:length(imgNo)
  imgRoot = sprintf('TI%03d',imgNo(cc));
  tt = sprintf('../images/biopsies/%s*',imgRoot);
  allImages = dir(tt);

  for i=1:length(allImages)
    imgNames{end+1} = allImages(i).name(1:end-4);
  end
end

for ii = 1:length(imgNames);
  biopsyClassify(type,imgNames{ii});
end

for ii = 1:length(imgNames);
  biopsyLabelImg(type,imgNames{ii});
end
