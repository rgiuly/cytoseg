function biopsyResultImg(type,imgName,dirToWrite)
% function biopsyResultImg(type,imgName,dirToWrite)

iterDirs = dir(sprintf('../%s_boost/biopsies/iter_*',type));
iter = 0;
for ff = 1:length(iterDirs);
  yy = sscanf(iterDirs(ff).name,'iter_%d');
  if(isempty(yy)); continue;end;
  if (yy>iter); iter = yy; end;
end


tic;

img = imread(['../images/biopsies/' imgName '.jpg']);
[h w d] = size(img);


eval(['load ../images/biopsies/' type '_scores/score_iter' num2str(iter) '_' imgName]);

resultImg = resultRegions(img, scoreImg>0,scoreImg<0);
imwrite(resultImg,sprintf('%s/%s_%s.jpg',dirToWrite,imgName,type),'jpg','Quality',95);