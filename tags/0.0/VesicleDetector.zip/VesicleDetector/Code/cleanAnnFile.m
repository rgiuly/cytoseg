function cleanAnnFile(imgName,curIter)
% function cleanAnnFile(imgName)

annFileName = sprintf('../images/biopsies/whole/%s.jpg.ann', imgName);
bckupAnnFileName =  sprintf('../images/biopsies/whole/oldAnnotations/%s.orig.%d.jpg.ann'...
  ,imgName,curIter);
cleanAnnFileName =  sprintf('../images/biopsies/whole/oldAnnotations/%s.clean.%d.jpg.ann'...
  ,imgName,curIter);
copyfile(annFileName,bckupAnnFileName);

annFile = fopen(annFileName,'r');
cleanAnnFile = fopen(cleanAnnFileName,'w');
while 1
  tline = fgetl(annFile);
  if ~ischar(tline),   break,   end
  if(strcmp(tline(1:4),'Box:'))
    if(strfind(tline,'Predicted')); continue; end
    fprintf(cleanAnnFile,tline);
    fprintf(cleanAnnFile,'\n');
  end
end
  
fclose(cleanAnnFile);
fclose(annFile);
copyfile(cleanAnnFileName,annFileName);