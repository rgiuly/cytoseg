function scoreImg = biopsyClassify(type,imgName,recalc)
% function scoreImg = biopsyClassify(type,imgName)

iter = findIteration(type);
scoreImgFile = sprintf('../images/biopsies/%s_scores/score_iter%d_%s.mat',type,iter,imgName);

if(nargin<3); recalc=0; end; % By default don't recalculate scores.
if(~recalc)
  if (exist(scoreImgFile,'file'))
    eval(['load ' scoreImgFile]);
    return;
  end
end


fprintf('Classifying %s for %s.. ',imgName,type);
img = imread(['../images/biopsies/' imgName '.jpg']);
[h w d] = size(img);

contourImg = biopsyFindOutline(type,imgName);

scoreImg = zeros(size(contourImg));
tic;

[labelImg ncomp] = regionsFromEdges(contourImg);

hsvimg = double(img);
hsvimg = hsvimg-min(hsvimg(:));
hsvimg = hsvimg/max(hsvimg(:));

if(strcmp(type,'grade5'))    % remove less saturated regions fast.
  satProps = regionprops(labelImg,hsvimg(:,:,2),'MeanIntensity');
  imgPos = ismember(labelImg,find([satProps.MeanIntensity]>0.2));
  [labelImg ncomp] = bwlabel(imgPos,4);
end

if(strcmp(type,'cancer'))
  glandPropsImg = biopsyClassify('gland',imgName);
  glandPropsBin{1} = [-inf -0.01 0.01 inf];
elseif(strcmp(type,'grade5'));
  glandPropsImg(:,:,1) = biopsyClassify('gland',imgName);
  glandPropsBin{1} = [-inf -0.01 0.01  inf];
  glandPropsImg(:,:,2) = biopsyClassify('cancer',imgName);
  glandPropsBin{2} = [-inf -0.01 0.01 inf];
else  
  glandPropsImg = [];
  glandPropsBin{1}=[];
end

imgPosProps = biopsyGetProps(img,labelImg>0,1,...
  glandPropsImg,glandPropsBin);


if(ncomp>0)
  predName = sprintf('%s_predict_iter%dVect',type,iter);
  tscores = boostClassify(predName,imgPosProps);
  tscores = [0; tscores];
  scoreImg = tscores(labelImg+1);
end


evalStr = sprintf('save ../images/biopsies/%s_scores/score_iter%d_%s scoreImg',type,iter,imgName);
eval(evalStr);
toc;
