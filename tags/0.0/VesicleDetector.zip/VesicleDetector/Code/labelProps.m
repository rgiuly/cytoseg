function props = labelProps(numRegions,curLabel)

props = repmat(struct('labels',curLabel),[numRegions 1]);
