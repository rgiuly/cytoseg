function props = findStructureProps(scores,extraStr,bins)
% function props = findStructureProps(filtimg,regions,extraStr)
% Finds histogram properties for low level structures

for j=1:size(scores,3);
  for i=1:length(bins{j})-1
    dummyStruct.(['struct_' num2str(j) '_' extraStr '_dim_' num2str(i)]) = 0;
  end
end

props = repmat(dummyStruct,[1 1]);

for j=1:size(scores,3)
  areaAll(j) = sum(sum(scores(:,:,j)~=0))+1;
end

for j = 1:size(scores,3)
  for i=1:length(bins{j})-1
    curFeature = sum(sum((scores(:,:,j)>bins{j}(i)) & (scores(:,:,j)<bins{j}(i+1))));
    curFeature = curFeature/areaAll(j);
    props(1).(['struct_' num2str(j) '_' extraStr '_dim_' num2str(i)]) = curFeature;
  end
end