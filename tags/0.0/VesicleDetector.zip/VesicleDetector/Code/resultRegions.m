function timg = resultRegions(img,imgPos,imgNeg)

% function resultImg = resultRegions(img,imgPos,imgNeg)

if(ndims(img)==2)
  img=repmat(img,[1 1 3]);
end

timg = img;

timgPos = uint8(imgPos);
timgNeg = uint8(imgNeg);

timgPosEdge = uint8(imdilate(timgPos,strel('disk',1)) & (~timgPos));
timgNegEdge = uint8(imdilate(timgNeg,strel('disk',1)) & (~timgNeg));
timgBothEdge = uint8(timgNegEdge&timgPosEdge);

% Pos edges as green.
timg(:,:,1) = timg(:,:,1)-255*timgPosEdge;
timg(:,:,2) = timg(:,:,2)+255*timgPosEdge;
timg(:,:,3) = timg(:,:,3)-255*timgPosEdge;

% Neg edges as red.
timg(:,:,1) = timg(:,:,1)+255*timgNegEdge;
timg(:,:,2) = timg(:,:,2)-255*timgNegEdge;
timg(:,:,3) = timg(:,:,3)-255*timgNegEdge;

% Both edges as yellow.
timg(:,:,1) = timg(:,:,1)+255*timgBothEdge;
timg(:,:,2) = timg(:,:,2)+255*timgBothEdge;
timg(:,:,3) = timg(:,:,3)-255*timgBothEdge;

