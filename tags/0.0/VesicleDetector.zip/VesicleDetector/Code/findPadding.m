function padding = findPadding(curPatchX,curPatchY,w,h,maxPad,blockSize)
% function padding = findPadding(curPatchX,curPatchY,h,w,maxPad,blockSize)

if(curPatchY<maxPad); padding(1)=curPatchY-1;
else padding(1) = maxPad; end
if(curPatchY+blockSize+maxPad>h)
  padding(3)=h-curPatchY-blockSize+1;
  if(padding(3)<0); padding(3)=0;end;
else padding(3) = maxPad;
end
if(curPatchX<maxPad); padding(2)=curPatchX-1;
else padding(2) = maxPad; end
if(curPatchX+blockSize+maxPad>w); 
  padding(4)=w-curPatchX-blockSize+1;
  if(padding(4)<0); padding(4)=0;end;
else padding(4) = maxPad; 
end

