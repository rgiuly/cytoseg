function curIter = findIteration(type)
% function curIter = findIteration(type)
% Finds the iteration for boosting.

boostDir = dir(sprintf('../%s_boost/biopsies/iter_*',type));
curIter = 0;
for ff = 1:length(boostDir)
  yy = sscanf(boostDir(ff).name,'iter_%d');
  if(isempty(yy)); continue;end;
  if(yy(1)>curIter);curIter = yy(1);end
end
