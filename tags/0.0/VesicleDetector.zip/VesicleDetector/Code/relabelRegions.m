function [selPos selNeg] = relabelRegions(img,imgPos,imgNeg,blockSize)

% function selComp = relabelRegions(img,imgPos,imgNeg,blockSize)
% displays image as 1000x1000 blocks 


imgComp = imgPos|imgNeg;
imgLabels = bwlabel(imgComp,4);
[h w] = size(imgComp);
selPos = false(h,w);
selNeg = false(h,w);

if(ndims(img)==2)
  img=repmat(img,[1 1 3]);
end

if(nargin<4); blockSize = 1000; end;

figno = figure;

for i=1:blockSize:h
for j=1:blockSize:w
  maxi = min(i+blockSize-1,h); maxj = min(j+blockSize-1,w);

  timgLabels = imgLabels(i:maxi,j:maxj);
  timg = img(i:maxi,j:maxj,:);

  timgPos = uint8(imgPos(i:maxi,j:maxj));
  timgNeg = uint8(imgNeg(i:maxi,j:maxj));
  tselPos = selPos(i:maxi,j:maxj);
  tselNeg = selNeg(i:maxi,j:maxj);

  timgPosEdge = uint8(imdilate(timgPos,strel('disk',1)) & (~timgPos));
  timgNegEdge = uint8(imdilate(timgNeg,strel('disk',1)) & (~timgNeg));
  timgBothEdge = uint8(timgNegEdge&timgPosEdge);
         
  % Pos edges as green.
  timg(:,:,1) = timg(:,:,1)-255*timgPosEdge;
  timg(:,:,2) = timg(:,:,2)+255*timgPosEdge;
  timg(:,:,3) = timg(:,:,3)-255*timgPosEdge;

  % Neg edges as red.
  timg(:,:,1) = timg(:,:,1)+255*timgNegEdge;  
  timg(:,:,2) = timg(:,:,2)-255*timgNegEdge;
  timg(:,:,3) = timg(:,:,3)-255*timgNegEdge;  

  % Both edges as yellow.
  timg(:,:,1) = timg(:,:,1)+255*timgBothEdge; 
  timg(:,:,2) = timg(:,:,2)+255*timgBothEdge;
  timg(:,:,3) = timg(:,:,3)-255*timgBothEdge;  

  figure(figno); imshow(timg); 
  title('Green Positive, Red Negative, Yellow Both');
  [xi,yi] = getpts;

while(~isempty(xi));

  c = round(axes2pix(size(timg,2), [1 size(timg,2)], xi));
  r = round(axes2pix(size(timg,1), [1 size(timg,1)], yi));
  locations = sub2ind(size(timgLabels),r,c);

  tselCompLab = timgLabels(locations);
  tselCompLab = setdiff(tselCompLab,0);
  ttoggle = ~ismember(timgLabels,tselCompLab);

  
  tselPos = (tselPos |(~ttoggle & timgNeg)) & (~(~ttoggle & timgPos));
  tselNeg = (tselNeg |(~ttoggle & timgPos)) & (~(~ttoggle & timgNeg));
  
  timgPos = ~xor(timgPos,ttoggle);
  timgNeg = ~xor(timgNeg,ttoggle);
  timgPosEdge = uint8(imdilate(timgPos,strel('disk',1)) & (~timgPos));
  timgNegEdge = uint8(imdilate(timgNeg,strel('disk',1)) & (~timgNeg));
  timgBothEdge = uint8(timgNegEdge&timgPosEdge);
         
  % Pos edges as green.
  timg(:,:,1) = timg(:,:,1)-255*timgPosEdge;
  timg(:,:,2) = timg(:,:,2)+255*timgPosEdge;
  timg(:,:,3) = timg(:,:,3)-255*timgPosEdge;

  % Neg edges as red.
  timg(:,:,1) = timg(:,:,1)+255*timgNegEdge;  
  timg(:,:,2) = timg(:,:,2)-255*timgNegEdge;
  timg(:,:,3) = timg(:,:,3)-255*timgNegEdge;  

  % Both edges as yellow.
  timg(:,:,1) = timg(:,:,1)+255*timgBothEdge; 
  timg(:,:,2) = timg(:,:,2)+255*timgBothEdge;
  timg(:,:,3) = timg(:,:,3)-255*timgBothEdge;  

  figure(figno); imshow(timg); 
  title('Green Positive, Red Negative, Yellow Both');
  [xi,yi] = getpts;

end

selPos(i:maxi,j:maxj) = tselPos;
selNeg(i:maxi,j:maxj) = tselNeg;

end
end

close(figno);
