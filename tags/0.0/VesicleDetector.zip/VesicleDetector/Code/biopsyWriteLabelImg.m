function biopsyWriteLabelImg(type,imgName,dirToWrite)
% function biopsyWriteLabelImg(type,imgName,dirToWrite)

tic;

img = imread(['../images/biopsies/' imgName '.jpg']);

labelFile = ['../images/biopsies/' type '_labels/' imgName '_label.mat'];
if(exist(labelFile,'file'));
  eval(['load ' labelFile] );
  if(sum(sum(imgPos))>1 || sum(sum(imgNeg))>1); 
    labelImg = resultRegions(img, imgPos,imgNeg);
    imwrite(labelImg,sprintf('%s/%s_%s_label.jpg',dirToWrite,imgName,type),'jpg','Quality',95);
  end
end
