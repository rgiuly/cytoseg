function biopsyRestart(type)

dirName = ['../images/biopsies/' type '_'];

rmdir([dirName 'boost'],'s');
mkdir([dirName 'boost']);
rmdir([dirName 'props'],'s');
mkdir([dirName 'props']);
rmdir([dirName 'scores'],'s');
mkdir([dirName 'scores']);
rmdir([dirName 'training_props'],'s');
mkdir([dirName 'training_props']);

reCalcProps(curDir);
