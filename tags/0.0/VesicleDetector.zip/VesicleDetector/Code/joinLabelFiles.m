type = 'cancer';

labelDir = sprintf('../images/biopsies/%s_labels/iter_*',type);
allLabels = dir(labelDir);

for i=1:length(allLabels)
  yy = sscanf(allLabels(i).name,'iter_%d_label_TI%d_%d_%d.mat');
  fprintf('Iter:%d img:TI%03d_%d_%d\n',yy(1),yy(2),yy(3),yy(4));
  imgName = sprintf('TI%03d_%d_%d',yy(2),yy(3),yy(4));
  combLabelFile = sprintf('../images/biopsies/%s_labels/%s_label.mat',type,imgName);
  
  if(exist(combLabelFile,'file')); 
    eval(sprintf('load %s',combLabelFile)); 
    combPos = imgPos; combNeg = imgNeg;
    combPosExist = 1;
  else
    combPosExist = 0;
  end
  
  eval(sprintf('load ../images/biopsies/%s_labels/%s',type,allLabels(i).name));
  
  if(combPosExist<1);
    combPos = imgPos; combNeg = imgNeg;
  end
  
  if( sum(sum(combPos & imgNeg))>0 || sum(sum(combNeg & imgPos))>0)
    fprintf('incorrect labels for %s !!!\n',allLabels(i).name);
    misMatch = combPos & imgNeg;
    combPos = combPos & ~misMatch;
    imgNeg = imgNeg & ~misMatch;
    
    misMatch = combNeg & imgPos;
    combNeg = combNeg & ~misMatch;
    imgPos = imgPos & ~misMatch;
    
  end
  
  combPos = combPos | imgPos; 
  combNeg = combNeg | imgNeg;
  
  imgPos = combPos; imgNeg = combNeg;
  
  eval(sprintf('save %s imgPos imgNeg',combLabelFile));
  
end