num= 44;
imgName = ['GrantImage' num2str(num) 'Tiny'];
imgNameSmall = ['GrantImage' num2str(num) 'Small'];
biopsyClassify('grade5',imgName);

img = imread(['../images/biopsies/' imgNameSmall '.jpg']);
timg = img;

type ='gland';
iter = findIteration(type);
eval(['load ../images/biopsies/' type '_scores/score_iter' num2str(iter) ...
  '_' imgName '.mat']);
pos = imresize(scoreImg>0,2);
posEdge = uint8((~imerode(pos,strel('disk',4))) & pos);
timg(:,:,1)= timg(:,:,1)-255*posEdge;
timg(:,:,2)= timg(:,:,2)+255*posEdge;
timg(:,:,3)= timg(:,:,3)-255*posEdge;

type ='cancer';
iter = findIteration(type);
eval(['load ../images/biopsies/' type '_scores/score_iter' num2str(iter) ...
  '_' imgName '.mat']);
pos = imresize(scoreImg>0,2);
posEdge = uint8((~imerode(pos,strel('disk',4))) & pos);
timg(:,:,1)= timg(:,:,1)+255*posEdge;
timg(:,:,2)= timg(:,:,2)-255*posEdge;
timg(:,:,3)= timg(:,:,3)-255*posEdge;

type ='grade5';
iter = findIteration(type);
eval(['load ../images/biopsies/' type '_scores/score_iter' num2str(iter) ...
  '_' imgName '.mat']);
pos = imresize(scoreImg>0,2);
posEdge = uint8((~imerode(pos,strel('disk',4))) & pos);
timg(:,:,1)= timg(:,:,1)-255*posEdge;
timg(:,:,2)= timg(:,:,2)-255*posEdge;
timg(:,:,3)= timg(:,:,3)+255*posEdge;
