
% imgNames = {'TI043_1_1','TI043_1_2','TI043_1_3',...
%   'TI051_1_1','TI051_1_2','TI051_1_3','TI051_1_4'};
imgNames = { 'TI050_1_1','TI050_1_2','TI050_1_3','TI050_1_4',...
  'TI057_2_1','TI057_2_2',...
  'TI059_1_1','TI059_1_2','TI059_1_3','TI059_1_4', 'TI059_1_5'...
  };

% imgNames = { 'TI060_2_1','TI060_2_2','TI060_2_3','TI060_2_4','TI060_2_5','TI060_2_6',...
%   'TI064_1_1','TI064_1_2',...
%   'TI068_1_1','TI068_1_2','TI068_1_3','TI068_1_4', 'TI068_1_5'...
%   };
% 
% imgNames = { 'TI066_1_1','TI066_1_2','TI066_1_3','TI066_1_4',...
% };
imgNames = {'TEST009_1_1'};

iter = 9;

for ii = 1:length(imgNames);
  biopsyClassify('cancer',imgNames{ii},iter);
end

for ii = 1:length(imgNames);
  biopsyLabelImg('cancer',imgNames{ii},iter);
end




type = 'cancer';
files = dir(['../images/biopsies/' type '_labels/']);
for i=1:length(files)
  yy = [];
  yy = sscanf(files(i).name,'iter_%d_label_%s');
  if(isempty(yy));continue;end;
  iter = yy(1);
  imgName = char(yy(2:end-4)');  
  evalStr = sprintf('load ../images/biopsies/%s_labels/iter_%d_label_%s.mat'...
    ,type,iter,imgName);
  eval(evalStr);
  
  img = imread(['../images/biopsies/' imgName '.jpg']);
  [d1 d2] = relabelRegions(img,imgPos,imgNeg);
  
end






ff = fopen('/home/mkabra/pros_class/matlab/edge_images/BSDS300/human/color/1103/2092.seg');
for i=1:100
  dump = fscanf(ff,'%s',1);
  if(strcmp(dump,'data')); break; end
end

i1_h1 = fscanf(ff,'%d %d %d %d\n',inf);
fclose(ff);

xx = zeros(size(i1,1), size(i1,2));
for i=1:size(i1_h1,1)
  xx(i1_h1(i,2)+1, (i1_h1(i,3)+1):(i1_h1(i,4)+1))=i1_h1(i,1);
end


tt1 = zeros(512,512);
tt2 = zeros(512,512);
for i=4:500
  for j=4:500
    c = mm(i-1:i+1,j-1:j+1,2);
    [a1 b1] = max(c(:));
    [a2 b2] = min(c(:));
    if( (b1==5))
      tt1(i,j)=a1;
    elseif((b2==5))
      tt2(i,j)=a2;
    end
  end
end



for i=1:5
  img = imread(['../new images/small_' num2str(i) '_1.jpg']);
  [h w d] = size(img);
  timg = reshape(img,[h*w d]);
  randpts = ceil(rand(5000,1)*h*w);
  xx = timg(randpts,:);
  xx = reshape(xx,[50 100 d]);
  [dump imgprops] = sep_colors(xx,3);
  iprops(i) = imgprops;
end

sform = makecform('srgb2lab');

xx = imread('../new images/1/1_1-10.jpg');
labxx = applycform(xx,sform);
txx = double(reshape(labxx,[1024*1024 3]));

sep_xx = zeros(1024*1024,4);
for i=1:4
  sep_xx(:,i) = iprops(1).weights(i)*mvnpdf(txx,iprops(1).means(:,i)',iprops(i).variance(:,:,i));
end
zz = sum(sep_xx,2);
for i=1:4
  sep_xx(:,i) = sep_xx(:,i)./zz;
end

sep_xx = reshape(sep_xx,1024,1024,4);




tt = img;

tt=i26;
[h w d]=size(tt);
randpts = ceil(rand(5000,1)*h*w);

cform = makecform('srgb2lab');
labimg = double(reshape(applycform(tt,cform),h*w,3));

[w1 m1 v1 l1]  = EM_GM(labimg(randpts,:),2);

cc1 = w1(1)*mvnpdf(labimg,m1(:,1)',v1(:,:,1));
cc2 = w1(2)*mvnpdf(labimg,m1(:,2)',v1(:,:,2));
cc = cc1+cc2;
cc1 = cc1./cc;
cc2 = cc2./cc;

overlay(tt,reshape(cc1,[h w])>0.9);
overlay(tt,reshape(cc2,[h w])>0.9);


qq = labimg(cc2>0.9,:);
randpts = ceil(rand(5000,1)*size(qq,1));

[w2 m2 v2 l2] = EM_GM(qq(randpts,:),3);
cc3 = w2(1)*mvnpdf(labimg,m2(:,1)',v2(:,:,1));
cc4 = w2(2)*mvnpdf(labimg,m2(:,2)',v2(:,:,2));
cc5 = w2(3)*mvnpdf(labimg,m2(:,3)',v2(:,:,3));


cc = cc3+cc4+cc5;
cc3 = cc3./cc;
cc4 = cc4./cc;
cc5 = cc5./cc;

dd1 = reshape(cc1,h,w);
dd2 = reshape(cc2,h,w);
dd3 = reshape(cc3,h,w);
dd4 = reshape(cc4,h,w);
dd5 = reshape(cc5,h,w);

overlay(tt, (dd2>0.9) & (dd3>0.9));
overlay(tt, (dd2>0.9) & (dd4>0.9));
overlay(tt, (dd2>0.9) & (dd5>0.9));






biopsy_label_img(2,5);
biopsy_get_props(2,5);

all_train_props = [];
load ../images/biopsies/training_props/training_props_16
all_train_props = [all_train_props; train_props];
load ../images/biopsies/training_props/training_props_3
all_train_props = [all_train_props; train_props];
load ../images/biopsies/training_props/training_props_7
all_train_props = [all_train_props; train_props];
load ../images/biopsies/training_props/training_props_8
all_train_props = [all_train_props; train_props];
load ../images/biopsies/training_props/iter_2_training_props_17.mat
all_train_props = [all_train_props; train_props];
load ../images/biopsies/training_props/iter_3_training_props_17.mat
all_train_props = [all_train_props; train_props];
load ../images/biopsies/training_props/iter_4_training_props_17.mat
all_train_props = [all_train_props; train_props];
load ../images/biopsies/training_props/iter_5_training_props_2.mat
all_train_props = [all_train_props; train_props];


boost_learn('../gland_boost/biopsies/iter_5',temp);

score_img = biopsy_classify(2,5);

biopsy_get_props_g5(10,1);
biopsy_get_props_g5(17,2);
biopsy_get_props_g5(17,3);
biopsy_get_props_g5(17,4);
biopsy_get_props_g5(10,5);
biopsy_get_props_g5(20,6);
biopsy_get_props_g5(21,7);
biopsy_get_props_g5(9,7);
biopsy_get_props_g5(20,8);
biopsy_get_props_g5(21,9);

biopsy_boost_learn_g5(9);

biopsy_classify_g5(21,9);
biopsy_classify_g5(20,9);
biopsy_classify_g5(9,9);
biopsy_classify_g5(10,9);


biopsy_get_props('cancer',26,12);
biopsy_get_props('gland',26,12);
biopsy_get_props('grade5',26,10);

biopsy_get_props('cancer',28,12);
biopsy_get_props('gland',28,12);
biopsy_get_props('grade5',28,10);

biopsy_boost_learn('cancer',12);
biopsy_boost_learn('gland',12);
biopsy_boost_learn('grade5',12);

i=41;
cc=12; gg = 12; g5=10;
biopsy_classify('cancer',i,cc);
biopsy_classify('gland',i,gg);
biopsy_classify('grade5',i,g5);
eval(['load ../images/biopsies/cancer_scores/score_iter' num2str(cc) '_' num2str(i) '.mat']);
cancer_score = score_img;
eval(['load ../images/biopsies/grade5_scores/score_iter' num2str(g5) '_' num2str(i) '.mat']);
grade5_score = score_img;
eval(['load ../images/biopsies/gland_scores/score_iter' num2str(gg) '_' num2str(i) '.mat']);
gland_score = score_img;
cancer_score(1,1) = -25;
cancer_score(end,end) = 25;
gland_score(end,end) = 25;
grade5_score(end,end) = 25;
grade5_score(1,1) = -25;
gland_score(1,1) = -25;
figure; imagesc(cancer_score); axis equal
figure; imagesc(gland_score); axis equal
figure; imagesc(grade5_score); axis equal
img = imread(['../images/biopsies/' num2str(i) '.jpg']);
figure; imshow(img); axis on



biopsy_classify('cancer',28,11);
biopsy_classify('gland',28,11);
biopsy_classify('grade5',28,9);


i=30;
eval(['load ../images/biopsies/grade5_scores/score_iter13_' num2str(i) '.mat']);
grade5{i} = score_img;
xx = grade5{i}>0;
yy = bwdist(xx);
zz = histc(yy(:),[0:3:93 inf]);
pp = sum(sum(bwperim(xx)));
figure; bar([0:3:90], zz(1:31)/pp);
figure; bar([0:3:90], cumsum(zz(1:31))/pp);

biopsy_find_outline('cancer',13); biopsy_find_outline('gland',13); biopsy_find_outline('grade5',13);
biopsy_classify('cancer',13,13);biopsy_classify('gland',13,13);biopsy_classify('grade5',13,15);



xx = zeros(2000,2000);

for i=2:1999
  for j=2:1999
    if(abs(zz(i,j))<0.005)
      
      if(abs(zz(i+1,j))>abs(zz(i,j)))
        if(xx(i,j)<abs(abs(zz(i+1,j)-zz(i,j))))
          xx(i,j) = abs(abs(zz(i+1,j)-zz(i,j)));
        end
      end
      
      
      if(abs(zz(i-1,j))>abs(zz(i,j)))
        if(xx(i,j)<abs(abs(zz(i-1,j)-zz(i,j))))
          xx(i,j) = abs(abs(zz(i-1,j)-zz(i,j)));
        end
      end
      
      
      if(abs(zz(i,j+1))>abs(zz(i,j)))
        if(xx(i,j)<abs(abs(zz(i,j+1)-zz(i,j))))
          xx(i,j) = abs(abs(zz(i,j+1)-zz(i,j)));
        end
      end
      
      
      if(abs(zz(i,j-1))>abs(zz(i,j)))
        if(xx(i,j)<abs(abs(zz(i,j-1)-zz(i,j))))
          xx(i,j) = abs(abs(zz(i,j-1)-zz(i,j)));
        end
      end
      
      
    end
  end
end


llimg = imread('/home/mkabra/prosImages/tinyImage002_4.jpg');
hhimg = false(size(llimg,1),size(llimg,2));
count = 0;
tic;
for ii=1:240/3:size(llimg,1)-240
  for jj=1:240/3:size(llimg,2)-240
    patch = llimg(ii:ii+240,jj:jj+240,:);
    hsvp = rgb2hsv(patch);
    satPerc = sum(sum(hsvp(:,:,2)>0.2))/240/240;
    if(satPerc>.4); 
      count = count+1; 
      hhimg(ii:ii+240,jj:jj+240)=1;
    end
  end
  fprintf('.');
end
toc;
